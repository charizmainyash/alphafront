export const base_url = "https://alphazealmedia.onrender.com";
// export const base_url = "http://localhost:8009/";

